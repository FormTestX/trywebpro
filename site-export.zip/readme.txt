=== Antonia ===
Contributors: Automattic
Requires at least: 5.8
Tested up to: 5.9
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Antonia is a theme for selling products with the help of payments block.

== Changelog ==

= 0.0.4 =
* Typography fixes (#6260)

= 0.0.3 =
* Migrate antonia fonts to new Blockbase format (#6268)

= 0.0.2 =
* Update theme url (#6076)

= 0.0.1 =
* Initial release

== Copyright ==

Antonia WordPress Theme, (C) 2022 Automattic
Antonia is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Antonia uses the following third-party resources:

Office Furniture by Scopic LTD:
https://unsplash.com/photos/NLlWwR4d3qU
https://unsplash.com/photos/Q2e2pLmUBjM
